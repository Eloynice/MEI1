upcc -network=smp catmouse100.upc versão 100 numeros
ou
upcc -network=smp catmouse1000.upc versão 1000 numeros


upcrun -n NPROCS ./a.out

NPROCS >= 4
